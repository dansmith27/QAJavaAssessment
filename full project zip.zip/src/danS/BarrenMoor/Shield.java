package danS.BarrenMoor;

//subclass for polymorphic function
public class Shield extends Object {
	public void use() {
		System.out.println("*Ducks Behind Shield*");
	}
}

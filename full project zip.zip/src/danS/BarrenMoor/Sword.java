package danS.BarrenMoor;

//subclass for polymorphic function
public class Sword extends Object {
	public void use() {
		System.out.println("*Swings Sword*");
	}
}
